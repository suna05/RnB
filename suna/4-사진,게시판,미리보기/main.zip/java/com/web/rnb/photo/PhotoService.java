package com.web.rnb.photo;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;


public interface PhotoService {
  
  //void insertPhoto(HttpServletRequest request,MultipartFile multipartFile, PhotoDTO pdto);
  List<PhotoDTO> getListPhoto();
  /*void updatePhoto(PhotoDTO pdto);
  void deletePhoto(PhotoDTO pdto);*/
  //void insertBoardPhoto(PhotoDTO pdto);
  //void insertPhoto(PhotoDTO pdto);
  //void insertPhoto(HttpServletRequest request, MultipartFile multipartFile, PhotoDTO pdto);
  void insertPhoto(PhotoDTO pdto);

  //PhotoDTO getBoardPhoto(PhotoDTO pdto);
  //void insertBoardPhoto(BoardPhotoDTO pdto);

  //BoardPhotoDTO getBoardPhoto(PhotoDTO pdto);
  
}
