package com.web.rnb;

import javax.annotation.Resource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.junit.Assert.assertThat;

import com.web.rnb.member.MemberDTO;
import com.web.rnb.member.MemberService;

//JUnit Ȯ���ɵ�(import���� �������� �־�����Ѵ�)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/applicationContext.xml")
public class MemberDAOTest {
	@Resource(name="memberServiceImpl")
	MemberService memberService;
	
	@Test
	public void insertMember() {
		MemberDTO mdto=new MemberDTO();
		mdto.setM_id("yeoseong_yoon");
		mdto.setM_pw("1234");
		mdto.setM_name("������");
		mdto.setM_phone("010-6611-8156");
		mdto.setM_birth("12/23");
		mdto.setM_address("����");
		System.out.println(mdto.toString());
		memberService.insertMember(mdto);
		
		MemberDTO mdto2=memberService.getMember(mdto);
		System.out.println(mdto2.toString());
	}
}
