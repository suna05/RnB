package com.web.rnb.write;

import java.util.List;


public interface WriteService {
  
  void insertWrite(WriteDTO wdto);
  List<WriteDTO> getListWrite();
 // List<PhotoDTO> photolist(int PageNo, int pageSize) throws Exception;
  /*void updatePhoto(PhotoDTO pdto);
  void deletePhoto(PhotoDTO pdto);*/
  WriteDTO getWrite(WriteDTO wdto);
}
