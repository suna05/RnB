package com.web.rnb.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.rnb.write.WriteDTO;
import com.web.rnb.write.WriteService;


@Controller
public class WriteController {
  
  @Autowired 
  WriteService writeService;
 
  @RequestMapping(value="/insertWrite.do", method=RequestMethod.POST)
  public ModelAndView insertWrite(WriteDTO wdto, ModelAndView mav) {
    System.out.println(wdto.getW_content());
    if(wdto==null) {
      System.out.println("null!!!");
    }
      writeService.insertWrite(wdto);
      System.out.println("insertWrite");
      mav.setViewName("redirect:getListWrite.do");
      return mav;
  }
  
  
  @RequestMapping(value="/getListWrite.do")
  public ModelAndView getListWrite(ModelAndView mav)  {
   
   if(mav==null) {
     System.out.println("mav null");
   }
   
   ArrayList<WriteDTO> list=(ArrayList<WriteDTO>) writeService.getListWrite();
   System.out.println("getListwrite");
      
      Iterator<WriteDTO> it=list.iterator();
      while(it.hasNext()){
        System.out.println(it.next().toString());
      }
      
      //model.addAttribute("list", teacherService.list(pageNo, pageSize));
      //mav.addObject("getListWrite",list);
      mav.addObject("getListWrite",list);
      
      mav.setViewName("getListWrite");
      return mav;
      
      
  }
  
 }
 
