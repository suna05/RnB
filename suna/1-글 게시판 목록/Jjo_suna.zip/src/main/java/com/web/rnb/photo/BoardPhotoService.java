package com.web.rnb.photo;

import com.web.rnb.photo.*;

public interface BoardPhotoService {

    void insertBoardPhoto(BoardPhotoDTO pdto);

    BoardPhotoDTO getBoardPhoto(PhotoDTO pdto);

}
